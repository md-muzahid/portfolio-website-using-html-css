
<!DOCTYPE html> 
<html> 
<head>
  <link rel="stylesheet" href="CSS/style.css">
</head>

<body> 
<a href="http://localhost/muzahids/home.html">home</a>
<h1>welcome to Admin panel</h1>

<?php 
include_once('connection.php'); 
?>

   <form action="" method="post">
			<div> Name: <input type="text" name="names" value="" /> </br>
			      Email: <input type="text" name="email" value="" /></br>
				  phone: <input type="text" name="feedback" value="" /></br>
			<input type="submit" name="submit" value="Insert" /></div>
	</form>
<?php 
if(isset($_POST['submit']))
{

	if(!empty ($_POST['names']) && !empty ($_POST['email']) && !empty ($_POST['feedback'])){
		$name= $_POST['names'];
		$Dept= $_POST['email'];
		$fedback= $_POST['feedback'];
		
	$sql = "INSERT INTO student(names,email,feedback) VALUES('$name','$Dept','$fedback')";
	$run =mysqli_query($mysqli,$sql) or die(mysqli_query());
	
	if($run){
		echo "<h1>Submitted Successfully..</h1>";
	}
		else{
			echo "<h1> Not Submitted </h1>";	
	}
	}
	else{
		echo "<h2> All Fields are required </h2>";
	}
}

?>


<?php

$sql = "SELECT 	names, email, feedback FROM student"; 
echo '<table style="width:60%" border="2" > 
      <tr> 
          <th>Name</font> </th> 
          <th>Email</font> </th> 
		  <th>phone</font> </th> 
		  <th><font color="green">Edit</font></th>
          <th><font color="Red">Delete</font></th>
      </tr>';

if ($result = $mysqli->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $Name = $row["names"];
        $Dept = $row["email"]; 
		$fedback= $row["feedback"];

        echo '<tr> 
                  <td>'.$Name.'</td> 
                  <td>'.$Dept.'</td>
				  <td>'.$fedback.'</td>
				  <td>  
		             <button class="btn btn-primary"> <a href="edit.php?updateid='.$Dept.'" >Update</a></button>	                
				  </td> 
				  
				   <td>  
		             <button class="btn btn-primary"> <a href="delete.php?deleteid='.$Dept.'">Delete</a></button>	                 
				  </td> 
				  
				   
			
		          
              </tr>';
    }
    $result->free();
} 
$mysqli ->close();

?>


</body> 
</html>