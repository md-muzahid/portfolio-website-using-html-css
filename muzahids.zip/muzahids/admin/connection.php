
<?php
$username = "root"; 
$password = ""; 
$database = "muzahid"; 
$mysqli = new mysqli("localhost", $username, $password, $database); 
?>