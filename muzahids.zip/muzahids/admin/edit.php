
<!DOCTYPE html> 
<html> 
<head>
  <link rel="stylesheet" href="CSS/style.css">
</head>

<body> 

<h1> Data Updating</h1>


<?php 
include_once('connection.php'); 
?>


<?php 
		$Dept= $_GET['updateid']; 
		$sql= "SELECT * FROM student WHERE email='$Dept' ";
		$result=mysqli_query($mysqli,$sql);
		$row = mysqli_fetch_assoc($result);
		$name= $row['names'];
		$Dept= $row['email'];
		$fedback=$row['feedback'];
		 
		 if(isset($_POST['edit'])){
		  $name= $_POST['names'];
		  $Dept= $_POST['email'];
		  $fedback=$_POST['feedback'];

		  $sql = "UPDATE student SET names='$name',email='$Dept',feedback='$fedback' where email='$Dept' ";
		  $run =mysqli_query($mysqli,$sql) or die(mysqli_query());
           if($run){
		    echo "<h1>Data Edited</h1>";
		    header("location:home.php");
	       }
		else{
			echo "<h1> Data not Edited  </h1>";	
	    }
		  
		 }

?>

       <form action="#" method="post">
		   
			 Name: <input type="text" name="names" value=<?php echo $name;?>   /> </br>
			Email: <input type="text" name="email" value=<?php echo $Dept;?>   /></br>
			feedback: <input type="text" name="feedback" value=<?php echo $fedback;?>   /></br>
			<input type="submit" name="edit" value="Updated Data" />
	   </form>

</body> 
</html>