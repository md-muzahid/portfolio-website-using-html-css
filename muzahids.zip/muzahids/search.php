<!DOCTYPE html>
<html lang="en">
<head>
<title>search page</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
}


.header {
  background-color:  #bfc722;
  padding: 20px;
  text-align: center;
}


.topnav {
  overflow: hidden;
  background-color: #333;
}


.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}


.topnav a:hover {
  background-color: #ddd;
  color: black;
}


.column {
  float: left;
  padding: 10px;
  height: 550px;
}


.column.side {
  width: 25%;
}


.column.middle {
  background-color: aqua;
  text-align: center;
  width: 100%;
}


.row:after {
  content: "";
  display: table;
  clear: both;
}


table{
  background-color: lightgrey;
  width: 300px;
  border: 15px solid rgb(128, 102, 0);
  padding: 20px;
  margin: 20px 400px;
}
td, h1 {
  text-align: center;
}
h2 {
  color:red;
  text-align: center;
}


input[type=text] {
  width: 100%;
  padding: 10px 15px;
  margin: 8px 0;
  box-sizing: border-box;
}

.btnedit{
	background:green;
	padding:10px 30px;
	text-decoration:none;
}

.btndelete{
	background:red;
	padding:10px 30px;
	text-decoration:none;
}



@media screen and (max-width: 600px) {
  .column.side, .column.middle {
    width: 100%;
  }
}


</style>

</head>
<body>

<div class="header">
  <h1>Search Here</h1>
</div>

<div class="topnav">
    <a href="home.html">Home</a>
    <a href="about.html">About</a>
    <a href="http://localhost/muzahids/cont/">Contact</a>
    <a href="http://localhost/muzahids/admin/">Admin</a>
    <a href="search.php">Search</a>
    <a href="http://localhost/muzahids/login/login.php">User</a>
  </div>
<div class="row">
  
  
  <div class="column middle">
  <?php 
include_once('connc.php'); 
?>

</br>

<form action="#" method="post">
		    
			Searched by user name: <input type="text" name="st_name"/> </br>
			<input type="submit" name="search" value="Search" />
	   </form>
	   
	    <h1>Searched Data</h1>
	   
<?php 
	if(isset($_POST['search'])){
		   
				$id= $_POST['st_name']; 
				$sql= "SELECT id, st_name, st_dept FROM student WHERE st_name LIKE '%$id%'";
				$run =mysqli_query($mysqli,$sql);
				
	echo '<table style="width:50%" border="2" > 

      <tr> 
          <th>ID</font> </th> 
          <th> user Name</font> </th> 
          <th> user email.</font> </th> 
			    
      </tr>';
		
				  
	
       while ($row = mysqli_fetch_array($run)) {
						$ID = $row["id"];
						$Name = $row["st_name"];
						$Dept = $row["st_dept"]; 
	

                  echo '<tr> 
                  <td>'.$ID.'</td>
                  <td>'.$Name.'</td> 
                  <td>'.$Dept.'</td>
				  </tr>';	
				 }				      
	}
	


?>



<?php

    echo '<h1>Display Data</h1>';

$sql = "SELECT id, st_name, st_dept FROM student"; 
echo '<table style="width:50%" border="2" > 

      <tr> 
          <th>ID</font> </th> 
          <th> user Name</font> </th> 
          <th> user email.</font> </th> 
			  
		  
      </tr>';

if ($result = $mysqli->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $ID = $row["id"];
        $Name = $row["st_name"];
        $Dept = $row["st_dept"]; 
	

        echo '<tr> 
                  <td>'.$ID.'</td>
                  <td>'.$Name.'</td> 
                  <td>'.$Dept.'</td>			
				
		          
              </tr>';
    }
    $result->free();
} 
$mysqli ->close();

?>

  </div>
</div>
   
</body>
</html>