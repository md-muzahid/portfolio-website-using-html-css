
<?php
$username = "root"; 
$password = ""; 
$database = "jahid"; 
$mysqli = new mysqli("localhost", $username, $password, $database); 
?>